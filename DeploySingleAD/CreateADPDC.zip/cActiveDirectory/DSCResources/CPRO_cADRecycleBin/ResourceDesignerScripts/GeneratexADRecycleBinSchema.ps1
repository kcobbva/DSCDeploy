New-cDscResource -Name CPRO_cADRecycleBin -FriendlyName cADRecycleBin -ModuleName cActiveDirectory -Path . -Force -Property @(
    New-cDscResourceProperty -Name ForestFQDN -Type String -Attribute Key
    New-cDscResourceProperty -Name EnterpriseAdministratorCredential -Type PSCredential -Attribute Required
    New-cDscResourceProperty -Name RecycleBinEnabled -Type Boolean -Attribute Read
    New-cDscResourceProperty -Name ForestMode -Type String -Attribute Read
)
